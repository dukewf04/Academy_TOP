from View.View import View

if __name__ == "__main__":
    view = View()

    view.main_menu()